repo: trailcurrentoss/TrailCurrentCapstan
branch: main

## Last sync
date: 2026-10-08T18:10:38Z

### Updated in this project
- Capstan screens adapted to the Waveshare 1.8" knob (360×360, touch, no push)
- Added Peregrine voice and Playbill media apps

## Screen map
| Screen | Repo files |
| --- | --- |
| Tiercel.dc.html | DOCS/TrailCurrent rotary display prototype/Rotary Dial.dc.html, docs/screens.md |
